#include <iostream>
#include <algorithm> // Para std::copy

int main() {
    double a[11] = { /* Inicializar con valores seg�n sea necesario */ };
    double b[34] = {0}; // Inicializar b con ceros o con alg�n valor predeterminado

    // Copiar los elementos de a a b
    std::copy(a, a + 11, b);

    // Opcional: Imprimir el contenido de b para verificar
    std::cout << "Contenido del arreglo b despu�s de copiar a:" << std::endl;
    for (int i = 0; i < 34; ++i) {
        std::cout << "Elemento " << i << ": " << b[i] << std::endl;
    }

    return 0;
}
