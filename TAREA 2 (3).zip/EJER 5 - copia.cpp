#include <iostream>

int main() {
    int g[5]; // Declaramos el arreglo con 5 elementos

    // Inicializar todos los elementos con 8
    for (int i = 0; i < 5; ++i) {
        g[i] = 8;
    }

    // Opcional: Imprimir los valores para verificar
    for (int i = 0; i < 5; ++i) {
        std::cout << "Elemento " << i << ": " << g[i] << std::endl;
    }

    return 0;
}
