#include <iostream>
#include <limits> // Para std::numeric_limits

int main() {
    float w[99]; // Declaramos el arreglo con 99 elementos

    // Inicializar el arreglo (opcional, si es necesario)
    for (int i = 0; i < 99; ++i) {
        w[i] = static_cast<float>(i + 1); // Ejemplo de inicializaci�n
    }

    float min = std::numeric_limits<float>::max();
    float max = std::numeric_limits<float>::lowest();

    // Encontrar el valor m�nimo y m�ximo
    for (int i = 0; i < 99; ++i) {
        if (w[i] < min) min = w[i];
        if (w[i] > max) max = w[i];
    }

    // Imprimir los valores m�nimo y m�ximo
    std::cout << "Valor m�nimo del arreglo w: " << min << std::endl;
    std::cout << "Valor m�ximo del arreglo w: " << max << std::endl;

    return 0;
}
