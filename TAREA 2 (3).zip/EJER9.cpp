#include <iostream>

int main() {
    int t[2][3];

    // Inicializar cada elemento con cero usando un ciclo for anidado
    for (int i = 0; i < 2; ++i) {
        for (int j = 0; j < 3; ++j) {
            t[i][j] = 0;
        }
    }

    return 0;
}
