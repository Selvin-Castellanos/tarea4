#include <iostream>

int main() {
    int t[2][3];

    // Recibir valores de entrada para cada elemento del arreglo
    std::cout << "Introduce los valores para el arreglo t:" << std::endl;
    for (int i = 0; i < 2; ++i) {
        for (int j = 0; j < 3; ++j) {
            std::cout << "t[" << i << "][" << j << "] = ";
            std::cin >> t[i][j];
        }
    }

    return 0;
}
