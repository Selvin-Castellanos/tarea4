#include <iostream>

using namespace std;

const int MAX_NUMEROS = 20;  // M�ximo n�mero de entradas

// Funci�n para verificar si un n�mero ya existe en el arreglo
bool esDuplicado(const int arreglo[], int size, int numero) {
    for (int i = 0; i < size; ++i) {
        if (arreglo[i] == numero) {
            return true; // El n�mero ya existe
        }
    }
    return false; // El n�mero es �nico
}

int main() {
    int numeros[MAX_NUMEROS]; // Arreglo para almacenar los n�meros �nicos
    int count = 0; // Contador para el n�mero de entradas v�lidas

    cout << "Introduce 20 n�meros entre 10 y 100 (inclusive):" << endl;

    while (count < MAX_NUMEROS) {
        int numero;
        cout << "N�mero " << (count + 1) << ": ";
        cin >> numero;

        // Validar el n�mero ingresado
        if (numero < 10 || numero > 100) {
            cout << "N�mero fuera de rango. Debe estar entre 10 y 100." << endl;
            continue; // Ignorar este n�mero y seguir con la siguiente entrada
        }

        // Verificar si el n�mero es un duplicado
        if (esDuplicado(numeros, count, numero)) {
            cout << "N�mero duplicado. Por favor ingresa un n�mero diferente." << endl;
            continue; // Ignorar este n�mero y seguir con la siguiente entrada
        }

        // Almacenar el n�mero �nico en el arreglo
        numeros[count] = numero;
        ++count;
    }

    // Mostrar los n�meros �nicos almacenados
    cout << "N�meros �nicos introducidos:" << endl;
    for (int i = 0; i < count; ++i) {
        cout << numeros[i] << " ";
    }
    cout << endl;

    return 0;
}
