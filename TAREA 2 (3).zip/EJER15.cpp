#include <iostream>
#include <vector>

int main() {
    const int NUM_VENDEDORES = 10; // Puedes ajustar este n�mero seg�n el n�mero real de vendedores
    const int NUM_RANGOS = 9; // N�mero de rangos de salario

    // Arreglo para almacenar las ventas de cada vendedor
    double ventas[NUM_VENDEDORES] = {0};

    // Arreglo para contar cu�ntos vendedores caen en cada rango
    int conteoRangos[NUM_RANGOS] = {0};

    // Leer las ventas de los vendedores
    std::cout << "Introduce las ventas de cada vendedor:" << std::endl;
    for (int i = 0; i < NUM_VENDEDORES; ++i) {
        std::cout << "Ventas del vendedor " << (i + 1) << ": $";
        std::cin >> ventas[i];
    }

    // Calcular los salarios y contar cu�ntos caen en cada rango
    for (int i = 0; i < NUM_VENDEDORES; ++i) {
        double salario = 200 + 0.09 * ventas[i]; // Calcular salario
        int salarioTruncado = static_cast<int>(salario); // Truncar a entero

        // Determinar el rango del salario y actualizar el conteo
        if (salarioTruncado >= 200 && salarioTruncado <= 299) {
            conteoRangos[0]++;
        } else if (salarioTruncado >= 300 && salarioTruncado <= 399) {
            conteoRangos[1]++;
        } else if (salarioTruncado >= 400 && salarioTruncado <= 499) {
            conteoRangos[2]++;
        } else if (salarioTruncado >= 500 && salarioTruncado <= 599) {
            conteoRangos[3]++;
        } else if (salarioTruncado >= 600 && salarioTruncado <= 699) {
            conteoRangos[4]++;
        } else if (salarioTruncado >= 700 && salarioTruncado <= 799) {
            conteoRangos[5]++;
        } else if (salarioTruncado >= 800 && salarioTruncado <= 899) {
            conteoRangos[6]++;
        } else if (salarioTruncado >= 900 && salarioTruncado <= 999) {
            conteoRangos[7]++;
        } else if (salarioTruncado >= 1000) {
            conteoRangos[8]++;
        }
    }

    // Imprimir el conteo de vendedores en cada rango
    std::cout << "Conteo de vendedores en cada rango de salario:" << std::endl;
    std::cout << "$200 - $299: " << conteoRangos[0] << std::endl;
    std::cout << "$300 - $399: " << conteoRangos[1] << std::endl;
    std::cout << "$400 - $499: " << conteoRangos[2] << std::endl;
    std::cout << "$500 - $599: " << conteoRangos[3] << std::endl;
    std::cout << "$600 - $699: " << conteoRangos[4] << std::endl;
    std::cout << "$700 - $799: " << conteoRangos[5] << std::endl;
    std::cout << "$800 - $899: " << conteoRangos[6] << std::endl;
    std::cout << "$900 - $999: " << conteoRangos[7] << std::endl;
    std::cout << "$1000 en adelante: " << conteoRangos[8] << std::endl;

    return 0;
}
