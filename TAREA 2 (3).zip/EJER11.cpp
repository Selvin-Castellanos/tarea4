#include <iostream>
#include <limits> // Para std::numeric_limits

int main() {
    int t[2][3] = { /* Inicializar con valores si es necesario */ };

    int min = std::numeric_limits<int>::max();

    // Encontrar el valor m�nimo
    for (int i = 0; i < 2; ++i) {
        for (int j = 0; j < 3; ++j) {
            if (t[i][j] < min) {
                min = t[i][j];
            }
        }
    }

    // Imprimir el valor m�nimo
    std::cout << "El valor m�s peque�o en el arreglo t es: " << min << std::endl;

    return 0;
}
