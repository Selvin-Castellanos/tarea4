#include <iostream>

int main() {
    char f[] = "Ejemplo"; // Supongamos que el arreglo tiene al menos 7 caracteres
    std::cout << "El valor del elemento 6 es: " << f[5] << std::endl; // Recuerda que los �ndices comienzan en 0
    return 0;
}
