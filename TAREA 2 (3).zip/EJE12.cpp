#include <iostream>

int main() {
    int t[2][3] = { /* Inicializar con valores si es necesario */ };

    std::cout << "Elementos en la fila 0 de t:" << std::endl;
    for (int j = 0; j < 3; ++j) {
        std::cout << t[0][j] << " ";
    }
    std::cout << std::endl;

    return 0;
}
