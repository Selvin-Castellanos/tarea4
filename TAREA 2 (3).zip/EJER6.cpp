#include <iostream>

int main() {
    float c[100]; // Declaramos el arreglo con 100 elementos
    float total = 0;

    // Inicializar el arreglo (opcional, si es necesario)
    for (int i = 0; i < 100; ++i) {
        c[i] = i + 1; // Ejemplo de inicializaci�n
    }

    // Sumar el total de los elementos
    for (int i = 0; i < 100; ++i) {
        total += c[i];
    }

    // Imprimir el total
    std::cout << "El total de los elementos del arreglo es: " << total << std::endl;

    // Imprimir los elementos
    for (int i = 0; i < 100; ++i) {
        std::cout << "Elemento " << i << ": " << c[i] << std::endl;
    }

    return 0;
}
