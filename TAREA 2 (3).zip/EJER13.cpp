#include <iostream>

int main() {
    int t[2][3] = { /* Inicializar con valores si es necesario */ };
    int total = 0;

    // Totalizar los elementos de la columna 2 (�ndice 1)
    for (int i = 0; i < 2; ++i) {
        total += t[i][1];
    }

    // Imprimir el total
    std::cout << "La suma de los elementos de la columna 2 es: " << total << std::endl;

    return 0;
}
