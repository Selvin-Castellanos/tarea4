public class Main {
    public static void main(String[] args) {
        int tamanioArreglo = 3;
        int[][] tabla = {
            {1, 8},
            {2, 4, 6},
            {5}
        };

        // Imprimir los valores en formato tabular
        for (int i = 0; i < tamanioArreglo; i++) {
            for (int j = 0; j < tamanioArreglo; j++) {
                // Verificar si el �ndice de columna est� dentro del rango de la fila actual
                if (j < tabla[i].length) {
                    System.out.printf("%4d", tabla[i][j]); // Imprimir el valor con un ancho de campo de 4
                } else {
                    System.out.printf("%4s", " "); // Espacio en blanco para columnas no definidas
                }
            }
            System.out.println(); // Salto de l�nea despu�s de imprimir cada fila
        }
    }
}
