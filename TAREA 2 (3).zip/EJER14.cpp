#include <iostream>

int main() {
    int t[2][3] = { /* Inicializar con valores si es necesario */ };

    // Imprimir encabezados de columna
    std::cout << "   Col0 Col1 Col2" << std::endl;

    // Imprimir los elementos en formato tabular
    for (int i = 0; i < 2; ++i) {
        std::cout << "Fila " << i << " ";
        for (int j = 0; j < 3; ++j) {
            std::cout << " " << t[i][j] << " ";
        }
        std::cout << std::endl;
    }

    return 0;
}
