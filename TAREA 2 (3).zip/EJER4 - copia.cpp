#include <iostream>

int main() {
    float b[10]; // Declaramos el arreglo con 10 elementos

    // Solicitar un valor al usuario
    std::cout << "Introduce un valor para el elemento 4 del arreglo b: ";
    std::cin >> b[3]; // El �ndice 4 es b[3] ya que los �ndices comienzan en 0

    return 0;
}
